<form method="get" action="search.php">
		
			<input type="search" name="user" placeholder="Username" required>
		

		
	</form>

<style>
 input {
	 border-style: none;
    width: 130px;
	 height: 46px;
    box-sizing: border-box;
    border-radius: 222px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 0px 10px 3px 10px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
	 
}

	form {
    border: none;
}
	
	
input[type=text]:focus {
    width: 100%;
}
    
    .search {

    background-color: #3B5998;
    float: right;
    margin-top: 23px;
     
}
	
	
	 @media only screen and (max-width: 767px),
only screen and (max-device-width: 480px),
            only screen and (max-width: 767px) {
                
				
				 input {
    width: 130px;
	 height: 25px;
    font-size: 16px;
    background-color: white;
    background-image: url('searchicon.png');
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 0px 0px 3px 10px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
	 
}

input[type=text]:focus {
    width: 100%;
}
    
    .search {

    background-color: #3B5998;
    float: right;
    margin-top: 15px;
     
}
                
                          
        }

    </style>
