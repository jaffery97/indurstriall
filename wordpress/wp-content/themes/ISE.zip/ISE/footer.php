<link rel="stylesheet" media="all" href="css/style.css">
<style>


    
    #footer {
		background-image: url(images/bg_footer@2x.png);
		background-size: 30px 30px;
        
	}
</style>

<footer id="footer">
		<div class="container">
			<div class="cols">
				<div class="col">
					<h3>Customer Service</h3>
					<ul>
						<li><a href="http://www.globalindustrial.com/help">Help</a></li>
						<li><a href="contact.php">Contact Us</a></li>
						<li><a href="aboutus.php">About Us</a></li>
						<li><a href="terms&conditons.php">Terms & Conditions</a></li>
						<li><a href="privacypolicy.php">Privacy Policy </a></li>
					</ul>
				</div>
				<div class="col media">
					<h3>Social media</h3>
					<ul class="social">
						<li><a href="#"><span class="ico ico-fb"></span>Facebook</a></li>
						<li><a href="#"><span class="ico ico-tw"></span>Twitter</a></li>
						<li><a href="#"><span class="ico ico-gp"></span>Google+</a></li>
						<li><a href="#"><span class="ico ico-pi"></span>Pinterest</a></li>
					</ul>
				</div>
				<div class="col contact">
					<h3>Contact us</h3>
					<p>Indrustial Safety Enterprise INC.<br>54233 Avenue Street<br>New York</p>
					<p><span class="ico ico-em"></span><a href="#">info@indrustialsafetyenterprise.com</a></p>
					<p><span class="ico ico-ph"></span>(590) 423 446 924</p>
				</div>
				<div class="col newsletter">
					<h3>Join our newsletter</h3>
					<p>Sed ut perspiciatis unde omnis iste natus sit voluptatem accusantium doloremque laudantium.</p>
					<form action="#">
						<input type="text" placeholder="Your email address...">
						<button type="submit"></button>
					</form>
				</div>
			</div>
			<p class="copy">Copyright 2018 ISE. All rights reserved.</p>
		</div>
		<!-- / container -->
	</footer>
	<!-- / footer -->