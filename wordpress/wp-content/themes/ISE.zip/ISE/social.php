
<style>


    .sicon {
        width: 100%;
    }

</style>

		<div class="social">
            
            <img src="images/socialicon.png" alt="" class="sicon">
		
			</div>
			

